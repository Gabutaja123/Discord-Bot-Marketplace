const express = require('express');
const bodyParser = require('body-parser');
const { Client, GatewayIntentBits } = require('discord.js');
const axios = require('axios');
const keepAlive = require('./keep_alive');

const token = 'YOUR_DISCORD_BOT_TOKEN';
const xenditApiKey = 'YOUR_XENDIT_API_KEY';

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
});

const marketplace = [
    { name: "item1", price: 1000 },
    { name: "item2", price: 2000 }
];

const pendingPayments = {};

async function createQRIS(amount, userId) {
    const externalId = `order-${userId}-${Date.now()}`;
    const data = {
        external_id: externalId,
        amount: amount,
        type: 'STATIC',
        callback_url: 'https://your-repl-name.username.repl.co/webhook',
    };

    const response = await axios.post('https://api.xendit.co/qr_codes', data, {
        headers: {
            'Authorization': `Basic ${Buffer.from(xenditApiKey + ':').toString('base64')}`,
            'Content-Type': 'application/json',
        },
    });

    return {
        url: response.data.qr_code_url,
        external_id: externalId
    };
}

client.once('ready', () => {
    console.log('Bot Marketplace siap!');
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    if (message.content.toLowerCase() === '!marketplace') {
        let list = marketplace.map(i => `**${i.name}** - ${i.price} Coins`).join('\n');
        message.channel.send(`Selamat datang di Marketplace:\n${list}`);
    }

    if (message.content.toLowerCase().startsWith('!buy')) {
        const itemName = message.content.split(' ')[1];
        const item = marketplace.find(i => i.name.toLowerCase() === itemName.toLowerCase());

        if (item) {
            try {
                const { url, external_id } = await createQRIS(item.price, message.author.id);
                pendingPayments[external_id] = {
                    userId: message.author.id,
                    item: item.name,
                    status: 'pending'
                };
                message.channel.send(`Scan QRIS ini untuk membeli **${item.name}**:\n${url}`);
            } catch (error) {
                message.channel.send('Gagal membuat QRIS. Silakan coba lagi nanti.');
            }
        } else {
            message.channel.send('Item tidak ditemukan!');
        }
    }
});

const app = express();
app.use(bodyParser.json());

app.post('/webhook', (req, res) => {
    const payment = req.body;
    const paymentRecord = pendingPayments[payment.external_id];

    if (payment.status === 'PAID' && paymentRecord) {
        const userId = paymentRecord.userId;
        const itemName = paymentRecord.item;
        client.users.fetch(userId).then(user => {
            user.send(`✅ Pembayaran berhasil! Kamu telah membeli **${itemName}**. Terima kasih!`);
        });
        paymentRecord.status = 'paid';
    }

    res.status(200).send('OK');
});

keepAlive();
client.login(token);